import nltk

nltk.download("punkt")
nltk.download("snowball_data")
nltk.download("stopwords")
